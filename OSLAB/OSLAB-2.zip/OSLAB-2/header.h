
void sort(int array[], int size, int order);
void findhighest(int array[], int size, int postion);
void print(int array[], int size);